#version 330

// ItemsAdder text effects for 26.2 (core/text, shared by text, gui_text,
// *_grayscale, *_polygon_offset and *_see_through pipelines).
// Base: vanilla 26.2 core/text.vsh. IA logic from ia_overlay_26_1_plus
// rendertype_text.vsh, enabled only when !IS_SEE_THROUGH && !IS_GRAYSCALE.
// Under IS_GUI there is no UV2/Sampler2: Color is used instead of
// Color * sample_lightmap(...).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

#if !defined(IS_SEE_THROUGH) && !defined(IS_GRAYSCALE)
#define IA_FX
#moj_import <minecraft:globals.glsl>
#endif

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

#ifdef IA_FX

#if !defined(IS_GUI)
#define IA_LIGHT (sample_lightmap(Sampler2, UV2))
#else
#define IA_LIGHT (vec4(1.0))
#endif

#define hue(v)  ((.6+.6*cos(6.*(v)+vec4(0, 23, 21, 1)))+vec4(0., 0., 0., 1.) )

#define finalize() { texCoord0=UV0; }

float safeGameTime() {
    float gameTime=GameTime;

    if(gameTime <= 0.) {
        gameTime=.5;
    }
    return gameTime;
}

float scaledTime() {
    return safeGameTime()*12000.;
}

void f_6a6850bf(inout vec4 vertex) {
    gl_Position=ProjMat*ModelViewMat*vertex;
}

void f_d6b7ef0e() {
    vertexColor=Color*IA_LIGHT;
}

void f_2f241f71(inout vec4 vertex) {
    f_6a6850bf(vertex);
    if(Position.z==0. && gl_Position.x > .95) {
        vertexColor=vec4(0);
    }else{
        f_d6b7ef0e();
    }
        finalize();
}

void f_e60ff8f2() {
    vertexColor=hue(gl_Position.x+safeGameTime()*1000.)*IA_LIGHT;
}

void f_baef7837() {
    gl_Position.y+=sin(scaledTime()+(gl_Position.x*6)) / 150.;
}

void f_7586b62a(inout vec4 vertex) {
    f_6a6850bf(vertex);
    f_e60ff8f2();
    finalize();
}

void f_ad6af9f2(inout vec4 vertex) {
    f_6a6850bf(vertex);
    f_d6b7ef0e();
    f_baef7837();
    finalize();
}

void f_f27a912c(inout vec4 vertex) {
    f_6a6850bf(vertex);
    f_baef7837();
    f_e60ff8f2();
    finalize();
}

void f_5bf7dac4(inout vec4 vertex) {
    f_d6b7ef0e();
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_6a6850bf(vertex);
    finalize();
}

void f_c7918a64(inout vec4 vertex) {
    float vertexId=mod(gl_VertexID, 4.);
    if(vertex.z <= 0.) {
        if(vertexId==3. || vertexId==0.) {
            vertex.y+=cos(scaledTime() / 4)*.1;
            vertex.y+=max(cos(scaledTime() / 4)*.1, 0.);
        }
    }else{
        if(vertexId==3. || vertexId==0.) {
            vertex.y-=cos(scaledTime() / 4)*3;
            vertex.y-=max(cos(scaledTime() / 4)*4, 0.);
        }
    }
    f_e60ff8f2();
    f_6a6850bf(vertex);
    finalize();
}

void f_e0821e84(inout vec4 vertex, float speed) {
    f_6a6850bf(vertex);
    float blink=abs(sin(scaledTime()*speed));
    vertexColor=Color*blink*IA_LIGHT;
    finalize();
}

void f_9a4385b9(inout vec4 vertex) {
    f_6a6850bf(vertex);
    f_d6b7ef0e();
    vertexColor=vec4(1, 1, 1, vertexColor.a);
    finalize();
}

void ia_main() {
    vertexColor=Color*IA_LIGHT;

    vec4 vertex=vec4(Position, 1.);
    ivec3 iColor=ivec3(Color.xyz*255+vec3(.5));

    if(iColor==ivec3(255, 85, 85))
    {
        f_2f241f71(vertex);
        return;
    }

    if(fract(Position.z) < .1) {

        if(iColor==ivec3(19, 23, 9))
        {
            gl_Position=vec4(2, 2, 2, 1);
            f_d6b7ef0e();
            finalize();
            return;
        }

        if(iColor==ivec3(57, 63, 63)) {
            f_6a6850bf(vertex);
            f_d6b7ef0e();
            finalize();
            return;
        }

        if(iColor==ivec3(57, 63, 62)) {
            f_ad6af9f2(vertex);
            return;
        }

        if(iColor==ivec3(57, 62, 63)) {
            f_ad6af9f2(vertex);
            return;
        }

        if(iColor==ivec3(57, 62, 62)) {
            f_5bf7dac4(vertex);
            return;
        }

        if(iColor==ivec3(57, 61, 63)) {
            f_5bf7dac4(vertex);
            return;
        }

        if(iColor==ivec3(57, 61, 62)) {
            f_e0821e84(vertex, .5);
            return;
        }
    }

    if(iColor==ivec3(78, 92, 36))
    {
        f_9a4385b9(vertex);
        return;
    }

    if(iColor==ivec3(230, 255, 254))
    {
        f_7586b62a(vertex);
        return;
    }

    if(iColor==ivec3(230, 255, 250))
    {
        f_ad6af9f2(vertex);
        return;
    }

    if(iColor==ivec3(230, 251, 254))
    {
        f_f27a912c(vertex);
        return;
    }

    if(iColor==ivec3(230, 251, 250))
    {
        f_5bf7dac4(vertex);
        return;
    }

    if(iColor==ivec3(230, 247, 254))
    {
        f_c7918a64(vertex);
        return;
    }

    if(iColor==ivec3(230, 247, 250))
    {
        f_e0821e84(vertex, .5);
        return;
    }

    if(iColor==ivec3(255, 255, 254))
    {
        f_7586b62a(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 253))
    {
        f_ad6af9f2(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 25))
    {
        f_f27a912c(vertex);
        return;
    }

    if(iColor==ivec3(255, 255, 251))
    {
        f_5bf7dac4(vertex);
        return;
    }

    if(iColor==ivec3(255, 254, 254))
    {
        f_c7918a64(vertex);
        return;
    }

    f_6a6850bf(vertex);
    f_d6b7ef0e();
    finalize();
}

#endif // IA_FX

void main() {
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
#endif

#ifdef IA_FX
    ia_main();
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
#endif
}
